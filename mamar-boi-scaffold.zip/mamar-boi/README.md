# মামার বই (Mamar Boi) — backend & platform scaffold

A production-oriented foundation for the publishing / blogging / bookstore
platform described in the brief: Next.js 14 (App Router) + PostgreSQL via
Prisma + NextAuth, with role-based access control, a moderated blog system,
an order-flow bookstore, and an admin panel.

This is a **real, working scaffold** — auth, database schema, and the core
API routes are fully implemented and follow the security rules in the brief
(hashed passwords, server-side authorization, no hard-coded payment info,
server-recomputed order totals, audit logging). It is **not yet the finished
product**: the 3D visual design, rich-text editor, and a few admin screens
are intentionally left as follow-up work — see "What's left" below.

## Stack

- **Next.js 14** (App Router, mixes server components + API routes)
- **PostgreSQL + Prisma** — swap `datasource.provider` to `sqlite` in
  `prisma/schema.prisma` for zero-setup local dev
- **NextAuth** (credentials provider, JWT sessions, bcrypt hashing)
- **Zod** for server-side input validation on every write endpoint
- **DOMPurify** to sanitize any HTML a writer submits before it's stored
- React Three Fiber / Framer Motion / GSAP are listed as dependencies for
  the 3D hero + motion work described in the brief, but not wired up yet

## Getting started

```bash
npm install
cp .env.example .env
# edit .env: set DATABASE_URL, NEXTAUTH_SECRET (openssl rand -base64 32),
# and SEED_ADMIN_EMAIL / SEED_ADMIN_PASSWORD for your first Super Admin

npx prisma migrate dev --name init
npx prisma db seed

npm run dev
```

Then visit `/` for the site and `/admin` (after logging in with your seeded
Super Admin) for the admin panel. `/admin` is not linked from the public
nav, matching the brief's "not publicly advertised" requirement.

## What's implemented

- **Auth & accounts** — registration (`/register`), login (`/login`),
  bcrypt password hashing, JWT sessions (8h expiry), login-attempt
  throttling, role-based middleware guarding `/admin` and `/dashboard`.
- **Roles** — `USER → WRITER → EDITOR → ADMIN → SUPER_ADMIN`, enforced
  server-side in every API route via `src/lib/rbac.ts`. The client can never
  elevate its own role (registration always creates a `USER`; only a
  `SUPER_ADMIN` can grant `ADMIN`/`SUPER_ADMIN`).
- **Blog** — create/edit/delete own posts, categories, tags, likes
  (duplicate-proof via a DB unique constraint), threaded comments with a
  basic spam throttle, and a `DRAFT → PENDING_REVIEW → PUBLISHED/REJECTED`
  moderation workflow that admins act on from `/admin/posts`. Whether
  approval is required is a toggleable `AdminSetting`
  (`posts.require_approval`), not hard-coded.
- **Bookstore** — public catalog (`/books`), book detail with an order form,
  and a full order flow: prices and stock are always re-read server-side
  (never trusted from the client), stock is decremented inside the same DB
  transaction that creates the order, and each order gets a unique
  `MB-YYYY-NNNNNN` number.
- **Payments** — payment methods (bKash, bank transfer, COD, etc.) live in
  the database and are managed from `/admin/payment-methods` by a
  `SUPER_ADMIN` only. Nothing sensitive is hard-coded in the frontend.
- **Admin panel** — overview stats, post moderation, book management, order
  management with status updates, user management (role changes, suspend),
  and payment-method configuration. Every sensitive admin action writes an
  `AuditLog` row.
- **Security** — hashed passwords, HttpOnly/secure session cookies, Zod
  validation on all write endpoints, ownership + role checks on every
  mutation, sanitized rich-text HTML, order totals computed server-side.

## What's left to build

These are called out in code comments where relevant:

1. **3D hero & visual design system** — the brief's floating-book hero,
   glassmorphism nav, card hover depth, etc. This scaffold ships plain,
   readable HTML/CSS placeholders instead so you have something to click
   through; the actual visual pass (React Three Fiber scene, GSAP
   transitions, full typography/color system) is a separate, sizable piece
   of frontend work — happy to do that next as its own pass.
2. **Rich-text editor** — `/dashboard/new` currently uses a plain textarea.
   Swap in Tiptap (or similar); its output already flows through
   `sanitizeHtml()` and the moderation pipeline unchanged.
3. **Email/SMS/WhatsApp notifications** — `Notification` rows are created
   for new orders, and `Resend` is already a dependency, but actually
   sending email/SMS/WhatsApp needs your provider credentials wired into
   `src/app/api/orders/route.ts`.
4. **Email verification & password reset** — the `EmailVerificationToken`
   and `PasswordResetToken` tables exist; the request/confirm endpoints
   still need to be written once you've picked an email provider.
5. **Search** — global search across blogs/books/authors/tags described in
   the brief isn't implemented yet (Postgres full-text search or a service
   like Meilisearch/Algolia would both work well here).
6. **SEO metadata, sitemap, robots.txt, structured data** — not yet added;
   straightforward to add via Next's `generateMetadata` once page content
   is finalized.
7. **Public user profile pages, comment reporting UI, 2FA, rate limiting
   backed by Redis** (the in-memory limiter in `src/lib/rate-limit.ts` works
   for one server instance — swap it for Upstash Redis, whose env vars are
   already in `.env.example`, before scaling past a single instance).
8. **Legal pages, About/Contact pages, footer** — not yet built.

## Notes on scale & deployment

- Postgres + Prisma will comfortably handle "thousands of users/posts/
  orders"; add read replicas or caching only once you see it's needed.
- Deploy target: any Node host that supports Next.js 14 (Vercel is the path
  of least resistance; a VPS with PM2 + Nginx also works and gives you full
  control over the Postgres instance).
- Run `npx prisma migrate deploy` (not `migrate dev`) in production.
