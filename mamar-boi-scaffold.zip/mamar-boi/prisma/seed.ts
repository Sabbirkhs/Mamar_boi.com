import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  const adminEmail = process.env.SEED_ADMIN_EMAIL;
  const adminPassword = process.env.SEED_ADMIN_PASSWORD;

  if (!adminEmail || !adminPassword) {
    throw new Error("Set SEED_ADMIN_EMAIL and SEED_ADMIN_PASSWORD in your .env before seeding.");
  }

  const passwordHash = await bcrypt.hash(adminPassword, 12);

  const admin = await prisma.user.upsert({
    where: { email: adminEmail.toLowerCase() },
    update: {},
    create: {
      name: "Super Admin",
      username: "superadmin",
      email: adminEmail.toLowerCase(),
      passwordHash,
      role: "SUPER_ADMIN"
    }
  });
  console.log(`Super Admin ready: ${admin.email}`);

  // Default moderation + delivery settings — edit these in /admin/settings
  // (or directly via the admin API) at any time.
  await prisma.adminSetting.upsert({
    where: { key: "posts.require_approval" },
    update: {},
    create: { key: "posts.require_approval", value: JSON.stringify(true) }
  });
  await prisma.adminSetting.upsert({
    where: { key: "orders.delivery_charge" },
    update: {},
    create: { key: "orders.delivery_charge", value: JSON.stringify(8000) } // 80.00 BDT in paisa
  });

  // A couple of starter categories so the blog/bookstore aren't empty.
  const categories = ["উপন্যাস", "কবিতা", "মনস্তাত্ত্বিক থ্রিলার", "রাজনৈতিক-সামাজিক"];
  for (const name of categories) {
    await prisma.category.upsert({
      where: { name },
      update: {},
      create: { name, slug: slugifyBn(name) }
    });
  }

  // Cash on Delivery is a safe default that needs no account details.
  const existingCOD = await prisma.paymentMethod.findFirst({ where: { provider: "Cash on Delivery" } });
  if (!existingCOD) {
    await prisma.paymentMethod.create({
      data: {
        provider: "Cash on Delivery",
        instructions: "ডেলিভারির সময় পণ্য গ্রহণ করে মূল্য পরিশোধ করুন।",
        active: true,
        sortOrder: 0
      }
    });
  }

  console.log("Seed complete.");
}

// Prisma unique constraints need distinct slugs even for Bengali text; a
// naive transliteration is fine here since these are just a handful of
// admin-created categories, not user input.
function slugifyBn(input: string): string {
  return input
    .trim()
    .replace(/\s+/g, "-")
    .replace(/[^\u0980-\u09FF\w-]/g, "");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
