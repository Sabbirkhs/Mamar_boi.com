"use client";

// This is a plain-textarea placeholder for the content field. The brief asks
// for a rich-text editor (bold/italic/headings/images/etc.) — wire up Tiptap
// or a similar editor here and pass its serialized HTML into `content`;
// everything downstream (sanitizeHtml, moderation flow) already expects HTML.

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function NewPostPage() {
  const router = useRouter();
  const [form, setForm] = useState({ title: "", excerpt: "", content: "" });
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    const res = await fetch("/api/posts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form)
    });
    const data = await res.json();
    setLoading(false);
    if (!res.ok) {
      setError("পোস্ট তৈরি করা যায়নি।");
      return;
    }
    router.push("/dashboard");
  }

  return (
    <main className="container" style={{ maxWidth: 640, padding: "48px 20px" }}>
      <h1 className="display">নতুন পোস্ট</h1>
      <form onSubmit={submit} style={{ display: "grid", gap: 12, marginTop: 24 }}>
        <input placeholder="শিরোনাম" required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
        <input placeholder="সংক্ষিপ্ত বিবরণ" value={form.excerpt} onChange={(e) => setForm({ ...form, excerpt: e.target.value })} />
        <textarea placeholder="লেখা..." required rows={12} value={form.content} onChange={(e) => setForm({ ...form, content: e.target.value })} />
        {error && <p style={{ color: "crimson" }}>{error}</p>}
        <button type="submit" disabled={loading}>{loading ? "..." : "জমা দিন (পর্যালোচনার জন্য)"}</button>
      </form>
    </main>
  );
}
