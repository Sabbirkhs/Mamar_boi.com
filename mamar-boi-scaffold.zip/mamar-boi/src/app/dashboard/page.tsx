import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export default async function DashboardPage() {
  const session = await getServerSession(authOptions);
  const userId = (session?.user as any)?.id as string;

  const posts = await prisma.post.findMany({
    where: { authorId: userId },
    orderBy: { updatedAt: "desc" },
    include: { _count: { select: { likes: true, comments: true } } }
  });

  return (
    <main className="container" style={{ padding: "48px 20px" }}>
      <h1 className="display">আমার ড্যাশবোর্ড</h1>
      <p style={{ color: "var(--color-muted)" }}>স্বাগতম, {session?.user?.name}</p>

      <div style={{ marginTop: 24 }}>
        <a href="/dashboard/new" style={{ display: "inline-block", padding: "10px 20px", background: "var(--color-accent)", color: "#fff", borderRadius: 6, textDecoration: "none" }}>
          + নতুন পোস্ট লিখুন
        </a>
      </div>

      <table style={{ width: "100%", marginTop: 24, borderCollapse: "collapse" }}>
        <thead>
          <tr style={{ textAlign: "left", borderBottom: "1px solid var(--color-line)" }}>
            <th>শিরোনাম</th><th>অবস্থা</th><th>লাইক</th><th>মন্তব্য</th>
          </tr>
        </thead>
        <tbody>
          {posts.map((post) => (
            <tr key={post.id} style={{ borderBottom: "1px solid var(--color-line)" }}>
              <td>{post.title}</td>
              <td>{statusLabel(post.status)}</td>
              <td>{post._count.likes}</td>
              <td>{post._count.comments}</td>
            </tr>
          ))}
          {posts.length === 0 && (
            <tr><td colSpan={4} style={{ color: "var(--color-muted)", padding: "12px 0" }}>এখনও কোনো পোস্ট নেই।</td></tr>
          )}
        </tbody>
      </table>
    </main>
  );
}

function statusLabel(status: string) {
  const map: Record<string, string> = {
    DRAFT: "খসড়া",
    PENDING_REVIEW: "পর্যালোচনাধীন",
    APPROVED: "অনুমোদিত",
    PUBLISHED: "প্রকাশিত",
    REJECTED: "প্রত্যাখ্যাত",
    HIDDEN: "লুকানো"
  };
  return map[status] ?? status;
}
