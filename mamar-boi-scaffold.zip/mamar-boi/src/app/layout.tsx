import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "মামার বই — পড়ুন, লিখুন, প্রকাশ করুন",
  description: "মামার বই — একটি আধুনিক প্রকাশনা, ব্লগিং ও বই কমার্স প্ল্যাটফর্ম।"
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="bn">
      <body>{children}</body>
    </html>
  );
}
