"use client";

import { useState } from "react";
import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";

export default function RegisterPage() {
  const router = useRouter();
  const [form, setForm] = useState({ name: "", username: "", email: "", phone: "", password: "" });
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    const res = await fetch("/api/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form)
    });
    const data = await res.json();
    if (!res.ok) {
      setError(typeof data.error === "string" ? data.error : "কিছু একটা ভুল হয়েছে।");
      setLoading(false);
      return;
    }
    await signIn("credentials", { email: form.email, password: form.password, redirect: false });
    setLoading(false);
    router.push("/dashboard");
  }

  return (
    <main className="container" style={{ maxWidth: 420, padding: "64px 20px" }}>
      <h1 className="display">অ্যাকাউন্ট তৈরি করুন</h1>
      <form onSubmit={onSubmit} style={{ display: "grid", gap: 12, marginTop: 24 }}>
        <input placeholder="নাম" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
        <input placeholder="ইউজারনেম" required value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} />
        <input type="email" placeholder="ইমেইল" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
        <input placeholder="ফোন নম্বর" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
        <input type="password" placeholder="পাসওয়ার্ড" required value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
        {error && <p style={{ color: "crimson" }}>{error}</p>}
        <button type="submit" disabled={loading}>{loading ? "..." : "রেজিস্টার করুন"}</button>
      </form>
    </main>
  );
}
