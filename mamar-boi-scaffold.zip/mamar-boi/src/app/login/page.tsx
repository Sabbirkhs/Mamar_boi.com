"use client";

import { useState } from "react";
import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    const res = await signIn("credentials", { email, password, redirect: false });
    setLoading(false);
    if (res?.error) {
      setError(res.error);
      return;
    }
    router.push("/dashboard");
  }

  return (
    <main className="container" style={{ maxWidth: 420, padding: "64px 20px" }}>
      <h1 className="display">লগইন</h1>
      <form onSubmit={onSubmit} style={{ display: "grid", gap: 12, marginTop: 24 }}>
        <input type="email" placeholder="ইমেইল" required value={email} onChange={(e) => setEmail(e.target.value)} />
        <input type="password" placeholder="পাসওয়ার্ড" required value={password} onChange={(e) => setPassword(e.target.value)} />
        {error && <p style={{ color: "crimson" }}>{error}</p>}
        <button type="submit" disabled={loading}>{loading ? "..." : "লগইন করুন"}</button>
      </form>
    </main>
  );
}
