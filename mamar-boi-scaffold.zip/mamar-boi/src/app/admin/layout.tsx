import Link from "next/link";

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <div style={{ display: "grid", gridTemplateColumns: "220px 1fr", minHeight: "100vh" }}>
      <aside style={{ borderRight: "1px solid var(--color-line)", padding: 20 }}>
        <strong className="display">অ্যাডমিন প্যানেল</strong>
        <nav style={{ display: "grid", gap: 8, marginTop: 20 }}>
          <Link href="/admin">ওভারভিউ</Link>
          <Link href="/admin/posts">ব্লগ পোস্ট</Link>
          <Link href="/admin/books">বই</Link>
          <Link href="/admin/orders">অর্ডার</Link>
          <Link href="/admin/payment-methods">পেমেন্ট পদ্ধতি</Link>
          <Link href="/admin/users">ব্যবহারকারী</Link>
        </nav>
      </aside>
      <div style={{ padding: 20 }}>{children}</div>
    </div>
  );
}
