"use client";

import { useRouter } from "next/navigation";

const STATUSES = ["PENDING", "CONFIRMED", "PROCESSING", "SHIPPED", "DELIVERED", "CANCELLED"];

export default function OrderActions({ orderId, status }: { orderId: string; status: string }) {
  const router = useRouter();

  async function updateStatus(next: string) {
    await fetch(`/api/orders/${orderId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: next })
    });
    router.refresh();
  }

  return (
    <select defaultValue={status} onChange={(e) => updateStatus(e.target.value)}>
      {STATUSES.map((s) => (
        <option key={s} value={s}>{s}</option>
      ))}
    </select>
  );
}
