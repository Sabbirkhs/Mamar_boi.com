import { prisma } from "@/lib/prisma";
import OrderActions from "./order-actions";

export default async function AdminOrdersPage() {
  const orders = await prisma.order.findMany({
    include: { items: { include: { book: true } }, paymentMethod: true },
    orderBy: { createdAt: "desc" },
    take: 100
  });

  return (
    <main>
      <h1 className="display">অর্ডার ব্যবস্থাপনা</h1>
      <table style={{ width: "100%", marginTop: 24, borderCollapse: "collapse" }}>
        <thead>
          <tr style={{ textAlign: "left", borderBottom: "1px solid var(--color-line)" }}>
            <th>অর্ডার আইডি</th>
            <th>গ্রাহক</th>
            <th>বই</th>
            <th>মোট</th>
            <th>পেমেন্ট</th>
            <th>স্ট্যাটাস</th>
            <th>অ্যাকশন</th>
          </tr>
        </thead>
        <tbody>
          {orders.map((order) => (
            <tr key={order.id} style={{ borderBottom: "1px solid var(--color-line)" }}>
              <td>{order.orderNumber}</td>
              <td>
                {order.customerName}
                <div style={{ color: "var(--color-muted)", fontSize: "0.85rem" }}>{order.customerPhone}</div>
              </td>
              <td>
                {order.items.map((i) => (
                  <div key={i.id}>{i.book.title} × {i.quantity}</div>
                ))}
              </td>
              <td>৳{(order.total / 100).toFixed(0)}</td>
              <td>{order.paymentMethod?.provider ?? "—"}</td>
              <td>{order.status}</td>
              <td><OrderActions orderId={order.id} status={order.status} /></td>
            </tr>
          ))}
          {orders.length === 0 && (
            <tr><td colSpan={7} style={{ color: "var(--color-muted)", padding: "12px 0" }}>এখনও কোনো অর্ডার নেই।</td></tr>
          )}
        </tbody>
      </table>
    </main>
  );
}
