import { prisma } from "@/lib/prisma";
import ModerationActions from "./moderation-actions";

export default async function AdminPostsPage() {
  const posts = await prisma.post.findMany({
    where: { status: { in: ["PENDING_REVIEW", "PUBLISHED"] } },
    include: { author: { select: { name: true } } },
    orderBy: { createdAt: "desc" },
    take: 50
  });

  return (
    <main>
      <h1 className="display">ব্লগ পোস্ট মডারেশন</h1>
      <table style={{ width: "100%", marginTop: 24, borderCollapse: "collapse" }}>
        <thead>
          <tr style={{ textAlign: "left", borderBottom: "1px solid var(--color-line)" }}>
            <th>শিরোনাম</th><th>লেখক</th><th>অবস্থা</th><th>অ্যাকশন</th>
          </tr>
        </thead>
        <tbody>
          {posts.map((post) => (
            <tr key={post.id} style={{ borderBottom: "1px solid var(--color-line)" }}>
              <td>{post.title}</td>
              <td>{post.author.name}</td>
              <td>{post.status}</td>
              <td><ModerationActions postId={post.id} status={post.status} /></td>
            </tr>
          ))}
        </tbody>
      </table>
    </main>
  );
}
