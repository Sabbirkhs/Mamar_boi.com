"use client";

import { useRouter } from "next/navigation";

export default function ModerationActions({ postId, status }: { postId: string; status: string }) {
  const router = useRouter();

  async function act(action: string) {
    await fetch(`/api/admin/posts/${postId}/moderate`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action })
    });
    router.refresh();
  }

  return (
    <div style={{ display: "flex", gap: 8 }}>
      {status === "PENDING_REVIEW" && (
        <>
          <button onClick={() => act("approve")}>অনুমোদন</button>
          <button onClick={() => act("reject")}>প্রত্যাখ্যান</button>
        </>
      )}
      {status === "PUBLISHED" && <button onClick={() => act("hide")}>লুকান</button>}
    </div>
  );
}
