"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function PaymentMethodForm() {
  const router = useRouter();
  const [form, setForm] = useState({ provider: "", accountName: "", accountNumber: "", instructions: "" });
  const [error, setError] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    const res = await fetch("/api/admin/payment-methods", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form)
    });
    if (!res.ok) {
      setError("যোগ করা যায়নি (শুধু Super Admin এই কাজ করতে পারবে)।");
      return;
    }
    setForm({ provider: "", accountName: "", accountNumber: "", instructions: "" });
    router.refresh();
  }

  return (
    <form onSubmit={submit} style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 16 }}>
      <input placeholder="প্রোভাইডার (যেমন bKash)" required value={form.provider} onChange={(e) => setForm({ ...form, provider: e.target.value })} />
      <input placeholder="অ্যাকাউন্টের নাম" value={form.accountName} onChange={(e) => setForm({ ...form, accountName: e.target.value })} />
      <input placeholder="অ্যাকাউন্ট নম্বর" value={form.accountNumber} onChange={(e) => setForm({ ...form, accountNumber: e.target.value })} />
      <input placeholder="নির্দেশনা" value={form.instructions} onChange={(e) => setForm({ ...form, instructions: e.target.value })} style={{ flex: 1, minWidth: 200 }} />
      <button type="submit">যোগ করুন</button>
      {error && <p style={{ color: "crimson", width: "100%" }}>{error}</p>}
    </form>
  );
}
