"use client";

import { useRouter } from "next/navigation";

export default function PaymentMethodToggle({ id, active }: { id: string; active: boolean }) {
  const router = useRouter();

  async function toggle() {
    await fetch(`/api/admin/payment-methods/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ active: !active })
    });
    router.refresh();
  }

  return <button onClick={toggle}>{active ? "নিষ্ক্রিয় করুন" : "সক্রিয় করুন"}</button>;
}
