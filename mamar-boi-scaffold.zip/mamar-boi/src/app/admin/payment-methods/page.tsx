import { prisma } from "@/lib/prisma";
import PaymentMethodForm from "./payment-method-form";
import PaymentMethodToggle from "./payment-method-toggle";

export default async function AdminPaymentMethodsPage() {
  const methods = await prisma.paymentMethod.findMany({ orderBy: { sortOrder: "asc" } });

  return (
    <main>
      <h1 className="display">পেমেন্ট পদ্ধতি</h1>
      <p style={{ color: "var(--color-muted)" }}>
        এখানে যোগ করা পদ্ধতিগুলোই চেকআউট পেজে দেখানো হবে। অ্যাকাউন্ট নম্বর কখনও ফ্রন্টএন্ড কোডে হার্ডকোড করা হয় না।
      </p>
      <PaymentMethodForm />
      <table style={{ width: "100%", marginTop: 24, borderCollapse: "collapse" }}>
        <thead>
          <tr style={{ textAlign: "left", borderBottom: "1px solid var(--color-line)" }}>
            <th>প্রোভাইডার</th><th>অ্যাকাউন্ট</th><th>নির্দেশনা</th><th>সক্রিয়</th>
          </tr>
        </thead>
        <tbody>
          {methods.map((m) => (
            <tr key={m.id} style={{ borderBottom: "1px solid var(--color-line)" }}>
              <td>{m.provider}</td>
              <td>{m.accountName} {m.accountNumber}</td>
              <td>{m.instructions}</td>
              <td><PaymentMethodToggle id={m.id} active={m.active} /></td>
            </tr>
          ))}
          {methods.length === 0 && (
            <tr><td colSpan={4} style={{ color: "var(--color-muted)", padding: "12px 0" }}>এখনও কোনো পেমেন্ট পদ্ধতি যোগ করা হয়নি।</td></tr>
          )}
        </tbody>
      </table>
    </main>
  );
}
