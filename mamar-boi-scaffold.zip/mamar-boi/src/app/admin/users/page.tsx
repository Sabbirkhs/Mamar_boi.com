import { prisma } from "@/lib/prisma";
import UserActions from "./user-actions";

export default async function AdminUsersPage() {
  const users = await prisma.user.findMany({
    orderBy: { createdAt: "desc" },
    include: { _count: { select: { posts: true } } }
  });

  return (
    <main>
      <h1 className="display">ব্যবহারকারী ব্যবস্থাপনা</h1>
      <table style={{ width: "100%", marginTop: 24, borderCollapse: "collapse" }}>
        <thead>
          <tr style={{ textAlign: "left", borderBottom: "1px solid var(--color-line)" }}>
            <th>নাম</th><th>ইউজারনেম</th><th>পোস্ট</th><th>রোল</th><th>স্ট্যাটাস</th><th>অ্যাকশন</th>
          </tr>
        </thead>
        <tbody>
          {users.map((u) => (
            <tr key={u.id} style={{ borderBottom: "1px solid var(--color-line)" }}>
              <td>{u.name}</td>
              <td>@{u.username}</td>
              <td>{u._count.posts}</td>
              <td>{u.role}</td>
              <td>{u.status}</td>
              <td><UserActions userId={u.id} role={u.role} status={u.status} /></td>
            </tr>
          ))}
        </tbody>
      </table>
    </main>
  );
}
