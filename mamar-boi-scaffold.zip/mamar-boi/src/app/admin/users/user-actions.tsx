"use client";

import { useRouter } from "next/navigation";

const ROLES = ["USER", "WRITER", "EDITOR", "ADMIN", "SUPER_ADMIN"];

export default function UserActions({ userId, role, status }: { userId: string; role: string; status: string }) {
  const router = useRouter();

  async function update(body: Record<string, string>) {
    const res = await fetch(`/api/admin/users/${userId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    });
    if (res.ok) router.refresh();
  }

  return (
    <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
      <select defaultValue={role} onChange={(e) => update({ role: e.target.value })}>
        {ROLES.map((r) => <option key={r} value={r}>{r}</option>)}
      </select>
      <button onClick={() => update({ status: status === "ACTIVE" ? "SUSPENDED" : "ACTIVE" })}>
        {status === "ACTIVE" ? "সাসপেন্ড" : "সক্রিয় করুন"}
      </button>
    </div>
  );
}
