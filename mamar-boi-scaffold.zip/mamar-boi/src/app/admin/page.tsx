import { prisma } from "@/lib/prisma";

export default async function AdminOverviewPage() {
  const [users, posts, pendingPosts, books, orders, pendingOrders] = await Promise.all([
    prisma.user.count(),
    prisma.post.count(),
    prisma.post.count({ where: { status: "PENDING_REVIEW" } }),
    prisma.book.count(),
    prisma.order.count(),
    prisma.order.count({ where: { status: "PENDING" } })
  ]);

  const revenueAgg = await prisma.order.aggregate({
    _sum: { total: true },
    where: { status: { in: ["CONFIRMED", "PROCESSING", "SHIPPED", "DELIVERED"] } }
  });

  const stats = [
    { label: "মোট ব্যবহারকারী", value: users },
    { label: "মোট ব্লগ পোস্ট", value: posts },
    { label: "পর্যালোচনাধীন পোস্ট", value: pendingPosts },
    { label: "মোট বই", value: books },
    { label: "মোট অর্ডার", value: orders },
    { label: "পেন্ডিং অর্ডার", value: pendingOrders },
    { label: "রেভিনিউ", value: `৳${((revenueAgg._sum.total ?? 0) / 100).toFixed(0)}` }
  ];

  return (
    <main>
      <h1 className="display">ওভারভিউ</h1>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))", gap: 16, marginTop: 24 }}>
        {stats.map((s) => (
          <div key={s.label} style={{ border: "1px solid var(--color-line)", borderRadius: 8, padding: 16 }}>
            <div style={{ color: "var(--color-muted)", fontSize: "0.9rem" }}>{s.label}</div>
            <div style={{ fontSize: "1.6rem", fontWeight: 700 }}>{s.value}</div>
          </div>
        ))}
      </div>
    </main>
  );
}
