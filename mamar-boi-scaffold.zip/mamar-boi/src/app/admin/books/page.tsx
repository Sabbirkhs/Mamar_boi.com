import { prisma } from "@/lib/prisma";
import NewBookForm from "./new-book-form";

export default async function AdminBooksPage() {
  const books = await prisma.book.findMany({ orderBy: { createdAt: "desc" } });

  return (
    <main>
      <h1 className="display">বই ব্যবস্থাপনা</h1>
      <NewBookForm />
      <table style={{ width: "100%", marginTop: 24, borderCollapse: "collapse" }}>
        <thead>
          <tr style={{ textAlign: "left", borderBottom: "1px solid var(--color-line)" }}>
            <th>শিরোনাম</th><th>দাম</th><th>স্টক</th><th>স্ট্যাটাস</th>
          </tr>
        </thead>
        <tbody>
          {books.map((b) => (
            <tr key={b.id} style={{ borderBottom: "1px solid var(--color-line)" }}>
              <td>{b.title}</td>
              <td>৳{(b.price / 100).toFixed(0)}</td>
              <td>{b.stock}</td>
              <td>{b.hidden ? "লুকানো" : "সক্রিয়"}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </main>
  );
}
