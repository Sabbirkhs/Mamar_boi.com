"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function NewBookForm() {
  const router = useRouter();
  const [form, setForm] = useState({
    title: "", author: "", description: "", price: "", stock: "0"
  });
  const [error, setError] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    const res = await fetch("/api/books", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        title: form.title,
        author: form.author,
        description: form.description,
        price: Math.round(Number(form.price) * 100), // BDT -> paisa
        stock: Number(form.stock)
      })
    });
    if (!res.ok) {
      setError("বই যোগ করা যায়নি।");
      return;
    }
    setForm({ title: "", author: "", description: "", price: "", stock: "0" });
    router.refresh();
  }

  return (
    <form onSubmit={submit} style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 16 }}>
      <input placeholder="শিরোনাম" required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
      <input placeholder="লেখক" required value={form.author} onChange={(e) => setForm({ ...form, author: e.target.value })} />
      <input placeholder="দাম (৳)" type="number" required value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} />
      <input placeholder="স্টক" type="number" required value={form.stock} onChange={(e) => setForm({ ...form, stock: e.target.value })} />
      <input placeholder="বিবরণ" required value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} style={{ flex: 1, minWidth: 200 }} />
      <button type="submit">যোগ করুন</button>
      {error && <p style={{ color: "crimson", width: "100%" }}>{error}</p>}
    </form>
  );
}
