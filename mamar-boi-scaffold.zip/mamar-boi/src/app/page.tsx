import Link from "next/link";

// NOTE: This hero is a static placeholder. The floating-3D-book scene
// (Three.js / React Three Fiber, per the brief) is a separate visual-design
// pass — swap this section for a <BookHeroScene /> client component once
// you're ready to build that; see README "Next steps".
export default function HomePage() {
  return (
    <main>
      <section className="container" style={{ padding: "96px 20px", textAlign: "center" }}>
        <h1 className="display" style={{ fontSize: "3rem" }}>মামার বই</h1>
        <p style={{ color: "var(--color-muted)", fontSize: "1.25rem", marginTop: 8 }}>
          পড়ুন, লিখুন, প্রকাশ করুন।
        </p>
        <div style={{ display: "flex", gap: 16, justifyContent: "center", marginTop: 32, flexWrap: "wrap" }}>
          <Link href="/blog" style={ctaPrimary}>ব্লগ পড়ুন</Link>
          <Link href="/books" style={ctaSecondary}>বই অর্ডার করুন</Link>
          <Link href="/register" style={ctaSecondary}>লিখতে শুরু করুন</Link>
        </div>
      </section>
    </main>
  );
}

const ctaPrimary: React.CSSProperties = {
  background: "var(--color-accent)",
  color: "#fff",
  padding: "12px 28px",
  borderRadius: 6,
  textDecoration: "none",
  fontWeight: 600
};

const ctaSecondary: React.CSSProperties = {
  border: "1px solid var(--color-line)",
  padding: "12px 28px",
  borderRadius: 6,
  textDecoration: "none",
  fontWeight: 600
};
