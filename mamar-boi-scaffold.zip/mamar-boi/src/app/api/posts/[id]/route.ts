import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireOwnerOrRole, ForbiddenError, UnauthorizedError } from "@/lib/rbac";
import { createPostSchema, sanitizeHtml } from "@/lib/validation";

export async function GET(_req: Request, { params }: { params: { id: string } }) {
  const post = await prisma.post.findUnique({
    where: { id: params.id },
    include: {
      author: { select: { name: true, username: true, avatarUrl: true, bio: true } },
      category: true,
      tags: { include: { tag: true } },
      _count: { select: { likes: true, comments: true } }
    }
  });
  if (!post) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json({ post });
}

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  try {
    const existing = await prisma.post.findUnique({ where: { id: params.id } });
    if (!existing) return NextResponse.json({ error: "Not found" }, { status: 404 });

    // Only the author, or an EDITOR+, may edit a post.
    await requireOwnerOrRole(existing.authorId, "EDITOR");

    const body = await req.json();
    const parsed = createPostSchema.partial().safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
    }

    const data: Record<string, unknown> = { ...parsed.data };
    if (typeof data.content === "string") data.content = sanitizeHtml(data.content);

    // Editing a published post sends it back to review rather than silently
    // changing what's live — admin can re-approve instantly if trusted.
    if (existing.status === "PUBLISHED") data.status = "PENDING_REVIEW";

    const post = await prisma.post.update({ where: { id: params.id }, data });
    return NextResponse.json({ post });
  } catch (err) {
    return handleAuthError(err);
  }
}

export async function DELETE(_req: Request, { params }: { params: { id: string } }) {
  try {
    const existing = await prisma.post.findUnique({ where: { id: params.id } });
    if (!existing) return NextResponse.json({ error: "Not found" }, { status: 404 });

    await requireOwnerOrRole(existing.authorId, "EDITOR");
    await prisma.post.delete({ where: { id: params.id } });
    return NextResponse.json({ ok: true });
  } catch (err) {
    return handleAuthError(err);
  }
}

function handleAuthError(err: unknown) {
  if (err instanceof UnauthorizedError) return NextResponse.json({ error: err.message }, { status: 401 });
  if (err instanceof ForbiddenError) return NextResponse.json({ error: err.message }, { status: 403 });
  console.error(err);
  return NextResponse.json({ error: "Something went wrong" }, { status: 500 });
}
