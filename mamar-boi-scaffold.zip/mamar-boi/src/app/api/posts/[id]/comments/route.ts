import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/rbac";
import { createCommentSchema } from "@/lib/validation";

export async function GET(_req: Request, { params }: { params: { id: string } }) {
  const comments = await prisma.comment.findMany({
    where: { postId: params.id, parentId: null, hidden: false },
    include: {
      author: { select: { name: true, username: true, avatarUrl: true } },
      replies: {
        where: { hidden: false },
        include: { author: { select: { name: true, username: true, avatarUrl: true } } }
      },
      _count: { select: { likes: true } }
    },
    orderBy: { createdAt: "desc" }
  });
  return NextResponse.json({ comments });
}

export async function POST(req: Request, { params }: { params: { id: string } }) {
  const user = await requireUser();

  const post = await prisma.post.findUnique({ where: { id: params.id } });
  if (!post || post.status !== "PUBLISHED") {
    return NextResponse.json({ error: "Cannot comment on this post" }, { status: 400 });
  }

  const parsed = createCommentSchema.safeParse(await req.json());
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });

  // Basic spam guard: throttle by checking the user's last comment timestamp.
  const recent = await prisma.comment.findFirst({
    where: { authorId: user.id },
    orderBy: { createdAt: "desc" }
  });
  if (recent && Date.now() - recent.createdAt.getTime() < 5000) {
    return NextResponse.json({ error: "You're commenting too quickly." }, { status: 429 });
  }

  const comment = await prisma.comment.create({
    data: {
      postId: params.id,
      authorId: user.id,
      content: parsed.data.content,
      parentId: parsed.data.parentId
    }
  });

  return NextResponse.json({ comment }, { status: 201 });
}
