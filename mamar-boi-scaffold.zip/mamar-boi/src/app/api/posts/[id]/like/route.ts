import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/rbac";

export async function POST(_req: Request, { params }: { params: { id: string } }) {
  const user = await requireUser();

  const existing = await prisma.like.findUnique({
    where: { postId_userId: { postId: params.id, userId: user.id } }
  });

  if (existing) {
    await prisma.like.delete({ where: { id: existing.id } });
    const count = await prisma.like.count({ where: { postId: params.id } });
    return NextResponse.json({ liked: false, count });
  }

  await prisma.like.create({ data: { postId: params.id, userId: user.id } });
  const count = await prisma.like.count({ where: { postId: params.id } });
  return NextResponse.json({ liked: true, count });
}
