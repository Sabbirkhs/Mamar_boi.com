import { NextResponse } from "next/server";
import slugify from "slugify";
import { nanoid } from "nanoid";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/rbac";
import { createPostSchema, sanitizeHtml } from "@/lib/validation";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const category = searchParams.get("category") ?? undefined;
  const tag = searchParams.get("tag") ?? undefined;
  const q = searchParams.get("q") ?? undefined;
  const page = Number(searchParams.get("page") ?? "1");
  const pageSize = 12;

  const posts = await prisma.post.findMany({
    where: {
      status: "PUBLISHED",
      ...(category ? { category: { slug: category } } : {}),
      ...(tag ? { tags: { some: { tag: { slug: tag } } } } : {}),
      ...(q ? { title: { contains: q, mode: "insensitive" } } : {})
    },
    include: {
      author: { select: { name: true, username: true, avatarUrl: true } },
      category: true,
      tags: { include: { tag: true } },
      _count: { select: { likes: true, comments: true } }
    },
    orderBy: { publishedAt: "desc" },
    skip: (page - 1) * pageSize,
    take: pageSize
  });

  return NextResponse.json({ posts, page, pageSize });
}

export async function POST(req: Request) {
  const user = await requireUser(); // any signed-in role (WRITER+) can submit a post

  const body = await req.json();
  const parsed = createPostSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }
  const { title, excerpt, content, coverImageUrl, categoryId, tagIds } = parsed.data;

  const safeContent = sanitizeHtml(content);
  const wordCount = safeContent.split(/\s+/).length;
  const readingTimeMin = Math.max(1, Math.round(wordCount / 200));

  const slug = `${slugify(title, { lower: true, strict: true })}-${nanoid(6)}`;

  // Admin setting controls whether writer posts publish immediately or need
  // review; default is the safer PENDING_REVIEW path.
  const moderationSetting = await prisma.adminSetting.findUnique({ where: { key: "posts.require_approval" } });
  const requiresApproval = moderationSetting ? JSON.parse(moderationSetting.value) : true;

  const post = await prisma.post.create({
    data: {
      title,
      slug,
      excerpt,
      content: safeContent,
      coverImageUrl,
      authorId: user.id,
      categoryId,
      readingTimeMin,
      status: requiresApproval ? "PENDING_REVIEW" : "PUBLISHED",
      publishedAt: requiresApproval ? null : new Date(),
      tags: tagIds ? { create: tagIds.map((tagId) => ({ tagId })) } : undefined
    }
  });

  return NextResponse.json({ post }, { status: 201 });
}
