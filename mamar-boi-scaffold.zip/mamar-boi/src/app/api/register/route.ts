import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { hashPassword, isPasswordStrongEnough } from "@/lib/password";
import { registerSchema } from "@/lib/validation";

export async function POST(req: Request) {
  const body = await req.json();
  const parsed = registerSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }
  const { name, username, email, phone, password } = parsed.data;

  if (!isPasswordStrongEnough(password)) {
    return NextResponse.json(
      { error: "Password must be at least 8 characters and include a letter and a number." },
      { status: 400 }
    );
  }

  const existing = await prisma.user.findFirst({
    where: { OR: [{ email: email.toLowerCase() }, { username }] }
  });
  if (existing) {
    return NextResponse.json({ error: "Email or username already in use." }, { status: 409 });
  }

  const passwordHash = await hashPassword(password);

  // Role is always server-assigned (USER by default) — the client can never
  // elevate its own privileges by sending a `role` field.
  const user = await prisma.user.create({
    data: {
      name,
      username,
      email: email.toLowerCase(),
      phone,
      passwordHash,
      role: "USER"
    },
    select: { id: true, name: true, username: true, email: true }
  });

  // TODO: send a verification email via Resend using EmailVerificationToken.
  // Kept out of this scaffold since it depends on your chosen email sender.

  return NextResponse.json({ user }, { status: 201 });
}
