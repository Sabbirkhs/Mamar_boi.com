import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/rbac";

export async function GET() {
  await requireRole("ADMIN");
  const settings = await prisma.adminSetting.findMany();
  return NextResponse.json({
    settings: Object.fromEntries(settings.map((s) => [s.key, JSON.parse(s.value)]))
  });
}

const setSchema = z.object({ key: z.string().min(1), value: z.any() });

export async function PUT(req: Request) {
  // Site-wide settings (payment credentials, moderation policy) are
  // SUPER_ADMIN-only; a compromised regular ADMIN account can't rewrite
  // payment instructions.
  const admin = await requireRole("SUPER_ADMIN");

  const parsed = setSchema.safeParse(await req.json());
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });

  const setting = await prisma.adminSetting.upsert({
    where: { key: parsed.data.key },
    create: { key: parsed.data.key, value: JSON.stringify(parsed.data.value) },
    update: { value: JSON.stringify(parsed.data.value) }
  });

  await prisma.auditLog.create({
    data: { actorId: admin.id, action: "setting.update", target: `AdminSetting:${setting.key}` }
  });

  return NextResponse.json({ setting });
}
