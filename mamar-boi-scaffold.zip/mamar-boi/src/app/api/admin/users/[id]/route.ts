import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/rbac";

const updateSchema = z.object({
  status: z.enum(["ACTIVE", "SUSPENDED"]).optional(),
  role: z.enum(["USER", "WRITER", "EDITOR", "ADMIN", "SUPER_ADMIN"]).optional()
});

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const admin = await requireRole("ADMIN");

  const parsed = updateSchema.safeParse(await req.json());
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });

  // Only a SUPER_ADMIN may grant ADMIN/SUPER_ADMIN, and nobody can demote or
  // suspend themselves through this endpoint.
  if (parsed.data.role && ["ADMIN", "SUPER_ADMIN"].includes(parsed.data.role) && admin.role !== "SUPER_ADMIN") {
    return NextResponse.json({ error: "Only a Super Admin can grant admin roles." }, { status: 403 });
  }
  if (params.id === admin.id) {
    return NextResponse.json({ error: "You cannot modify your own account here." }, { status: 400 });
  }

  const before = await prisma.user.findUnique({ where: { id: params.id } });
  if (!before) return NextResponse.json({ error: "Not found" }, { status: 404 });

  const user = await prisma.user.update({
    where: { id: params.id },
    data: parsed.data,
    select: { id: true, name: true, username: true, role: true, status: true }
  });

  await prisma.auditLog.create({
    data: {
      actorId: admin.id,
      action: "user.update",
      target: `User:${user.id}`,
      metadata: JSON.stringify({ before: { role: before.role, status: before.status }, after: parsed.data })
    }
  });

  return NextResponse.json({ user });
}
