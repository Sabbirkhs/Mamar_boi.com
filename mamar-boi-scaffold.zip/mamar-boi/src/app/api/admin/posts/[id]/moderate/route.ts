import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/rbac";

const schema = z.object({
  action: z.enum(["approve", "reject", "hide", "feature", "unfeature"]),
  rejectionNote: z.string().max(500).optional()
});

export async function POST(req: Request, { params }: { params: { id: string } }) {
  const editor = await requireRole("EDITOR");

  const parsed = schema.safeParse(await req.json());
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });

  const data: Record<string, unknown> = {};
  switch (parsed.data.action) {
    case "approve":
      data.status = "PUBLISHED";
      data.publishedAt = new Date();
      data.rejectionNote = null;
      break;
    case "reject":
      data.status = "REJECTED";
      data.rejectionNote = parsed.data.rejectionNote ?? "Does not meet publishing guidelines.";
      break;
    case "hide":
      data.status = "HIDDEN";
      break;
    case "feature":
      data.featured = true;
      break;
    case "unfeature":
      data.featured = false;
      break;
  }

  const post = await prisma.post.update({ where: { id: params.id }, data });

  await prisma.auditLog.create({
    data: { actorId: editor.id, action: `post.${parsed.data.action}`, target: `Post:${post.id}` }
  });

  return NextResponse.json({ post });
}
