import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/rbac";

const updateSchema = z.object({
  provider: z.string().min(1).max(60).optional(),
  accountName: z.string().max(120).optional(),
  accountNumber: z.string().max(60).optional(),
  instructions: z.string().max(500).optional(),
  active: z.boolean().optional(),
  sortOrder: z.number().int().optional()
});

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const admin = await requireRole("SUPER_ADMIN");
  const parsed = updateSchema.safeParse(await req.json());
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });

  const method = await prisma.paymentMethod.update({ where: { id: params.id }, data: parsed.data });

  await prisma.auditLog.create({
    data: { actorId: admin.id, action: "payment_method.update", target: `PaymentMethod:${method.id}` }
  });

  return NextResponse.json({ method });
}

export async function DELETE(_req: Request, { params }: { params: { id: string } }) {
  const admin = await requireRole("SUPER_ADMIN");
  await prisma.paymentMethod.delete({ where: { id: params.id } });
  await prisma.auditLog.create({
    data: { actorId: admin.id, action: "payment_method.delete", target: `PaymentMethod:${params.id}` }
  });
  return NextResponse.json({ ok: true });
}
