import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/rbac";

export async function GET() {
  await requireRole("ADMIN");
  const methods = await prisma.paymentMethod.findMany({ orderBy: { sortOrder: "asc" } });
  return NextResponse.json({ methods });
}

const createSchema = z.object({
  provider: z.string().min(1).max(60),
  accountName: z.string().max(120).optional(),
  accountNumber: z.string().max(60).optional(),
  instructions: z.string().max(500).optional(),
  active: z.boolean().optional(),
  sortOrder: z.number().int().optional()
});

export async function POST(req: Request) {
  // Payment credentials are sensitive — only a SUPER_ADMIN can create/edit
  // them, and they're only ever read server-side (never bundled to the client).
  const admin = await requireRole("SUPER_ADMIN");

  const parsed = createSchema.safeParse(await req.json());
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });

  const method = await prisma.paymentMethod.create({ data: parsed.data });

  await prisma.auditLog.create({
    data: { actorId: admin.id, action: "payment_method.create", target: `PaymentMethod:${method.id}` }
  });

  return NextResponse.json({ method }, { status: 201 });
}
