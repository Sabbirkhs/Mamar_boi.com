import { NextResponse } from "next/server";
import slugify from "slugify";
import { nanoid } from "nanoid";
import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/rbac";
import { createBookSchema } from "@/lib/validation";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const q = searchParams.get("q") ?? undefined;
  const category = searchParams.get("category") ?? undefined;
  const page = Number(searchParams.get("page") ?? "1");
  const pageSize = 12;

  const books = await prisma.book.findMany({
    where: {
      hidden: false,
      ...(q ? { title: { contains: q, mode: "insensitive" } } : {}),
      ...(category ? { categories: { some: { slug: category } } } : {})
    },
    include: { categories: true },
    orderBy: [{ featured: "desc" }, { createdAt: "desc" }],
    skip: (page - 1) * pageSize,
    take: pageSize
  });

  return NextResponse.json({ books, page, pageSize });
}

export async function POST(req: Request) {
  await requireRole("ADMIN"); // only admins/super-admins manage the catalog

  const parsed = createBookSchema.safeParse(await req.json());
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  const data = parsed.data;

  const slug = `${slugify(data.title, { lower: true, strict: true })}-${nanoid(6)}`;

  const book = await prisma.book.create({
    data: {
      title: data.title,
      slug,
      author: data.author,
      description: data.description,
      coverImageUrl: data.coverImageUrl,
      price: data.price,
      discountPrice: data.discountPrice,
      stock: data.stock,
      pages: data.pages,
      publisher: data.publisher,
      edition: data.edition,
      isbn: data.isbn,
      categories: data.categoryIds ? { connect: data.categoryIds.map((id) => ({ id })) } : undefined
    }
  });

  return NextResponse.json({ book }, { status: 201 });
}
