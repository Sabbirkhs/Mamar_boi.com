import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/rbac";
import { createBookSchema } from "@/lib/validation";

export async function GET(_req: Request, { params }: { params: { id: string } }) {
  const book = await prisma.book.findUnique({ where: { id: params.id }, include: { categories: true } });
  if (!book || book.hidden) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json({ book });
}

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  await requireRole("ADMIN");
  const parsed = createBookSchema.partial().safeParse(await req.json());
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });

  const { categoryIds, ...rest } = parsed.data;
  const book = await prisma.book.update({
    where: { id: params.id },
    data: {
      ...rest,
      categories: categoryIds ? { set: categoryIds.map((id) => ({ id })) } : undefined
    }
  });
  return NextResponse.json({ book });
}

export async function DELETE(_req: Request, { params }: { params: { id: string } }) {
  await requireRole("ADMIN");
  await prisma.book.delete({ where: { id: params.id } });
  return NextResponse.json({ ok: true });
}
