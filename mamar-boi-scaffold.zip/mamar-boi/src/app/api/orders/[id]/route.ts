import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/rbac";

export async function GET(_req: Request, { params }: { params: { id: string } }) {
  // Looked up by opaque cuid or the public order number — either way this
  // is intentionally not tied to a login, since guest checkout is supported.
  // It reveals only order/shipping status, never other customers' data.
  const order = await prisma.order.findFirst({
    where: { OR: [{ id: params.id }, { orderNumber: params.id }] },
    include: { items: { include: { book: true } }, paymentMethod: true }
  });
  if (!order) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json({ order });
}

const updateSchema = z.object({
  status: z.enum(["PENDING", "CONFIRMED", "PROCESSING", "SHIPPED", "DELIVERED", "CANCELLED"]).optional(),
  trackingInfo: z.string().max(300).optional()
});

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const admin = await requireRole("EDITOR");

  const parsed = updateSchema.safeParse(await req.json());
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });

  const before = await prisma.order.findUnique({ where: { id: params.id } });
  if (!before) return NextResponse.json({ error: "Not found" }, { status: 404 });

  const order = await prisma.order.update({ where: { id: params.id }, data: parsed.data });

  await prisma.auditLog.create({
    data: {
      actorId: admin.id,
      action: "order.update",
      target: `Order:${order.id}`,
      metadata: JSON.stringify({ before: { status: before.status }, after: parsed.data })
    }
  });

  return NextResponse.json({ order });
}
