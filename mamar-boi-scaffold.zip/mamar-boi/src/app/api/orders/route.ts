import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getCurrentUser, requireRole } from "@/lib/rbac";
import { createOrderSchema } from "@/lib/validation";
import { generateOrderNumber } from "@/lib/order-number";

// Flat delivery charge fallback; real value should come from AdminSetting
// ("orders.delivery_charge") so it's editable without a redeploy.
const DEFAULT_DELIVERY_CHARGE = 8000; // paisa => 80.00 BDT

export async function POST(req: Request) {
  const parsed = createOrderSchema.safeParse(await req.json());
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  const data = parsed.data;

  const paymentMethod = await prisma.paymentMethod.findUnique({ where: { id: data.paymentMethodId } });
  if (!paymentMethod || !paymentMethod.active) {
    return NextResponse.json({ error: "Selected payment method is unavailable." }, { status: 400 });
  }

  // Prices and stock are always re-read from the DB — never trust amounts
  // sent from the client.
  const bookIds = data.items.map((i) => i.bookId);
  const books = await prisma.book.findMany({ where: { id: { in: bookIds } } });

  let subtotal = 0;
  const orderItemsData: { bookId: string; quantity: number; unitPrice: number }[] = [];

  for (const item of data.items) {
    const book = books.find((b) => b.id === item.bookId);
    if (!book || book.hidden) {
      return NextResponse.json({ error: `Book unavailable: ${item.bookId}` }, { status: 400 });
    }
    if (book.stock < item.quantity) {
      return NextResponse.json({ error: `Not enough stock for "${book.title}".` }, { status: 400 });
    }
    const unitPrice = book.discountPrice ?? book.price;
    subtotal += unitPrice * item.quantity;
    orderItemsData.push({ bookId: book.id, quantity: item.quantity, unitPrice });
  }

  const deliverySetting = await prisma.adminSetting.findUnique({ where: { key: "orders.delivery_charge" } });
  const deliveryCharge = deliverySetting ? JSON.parse(deliverySetting.value) : DEFAULT_DELIVERY_CHARGE;
  const total = subtotal + deliveryCharge;

  const currentUser = await getCurrentUser();
  const orderNumber = await generateOrderNumber();

  const order = await prisma.$transaction(async (tx) => {
    const created = await tx.order.create({
      data: {
        orderNumber,
        userId: currentUser?.id,
        customerName: data.customerName,
        customerPhone: data.customerPhone,
        customerEmail: data.customerEmail,
        district: data.district,
        upazila: data.upazila,
        postalCode: data.postalCode,
        address: data.address,
        note: data.note,
        subtotal,
        deliveryCharge,
        total,
        paymentMethodId: data.paymentMethodId,
        paymentRef: data.paymentRef,
        items: { create: orderItemsData }
      },
      include: { items: { include: { book: true } } }
    });

    // Decrement stock inside the same transaction so it can't oversell.
    for (const item of orderItemsData) {
      await tx.book.update({ where: { id: item.bookId }, data: { stock: { decrement: item.quantity } } });
    }

    await tx.notification.create({
      data: {
        channel: "DASHBOARD",
        title: `New order ${created.orderNumber}`,
        body: `${data.customerName} ordered ${orderItemsData.length} item(s) — total ৳${(total / 100).toFixed(2)}.`,
        metadata: JSON.stringify({ orderId: created.id })
      }
    });

    return created;
  });

  // TODO: wire up real email/SMS/WhatsApp sending here (Resend is already a
  // dependency). Keep phone numbers and account details entirely server-side
  // and out of any client bundle — pull them from PaymentMethod/AdminSetting.

  return NextResponse.json({ order }, { status: 201 });
}

export async function GET(req: Request) {
  await requireRole("EDITOR"); // staff-only order list; customers use /orders/[id] with their own order number

  const { searchParams } = new URL(req.url);
  const status = searchParams.get("status") ?? undefined;
  const page = Number(searchParams.get("page") ?? "1");
  const pageSize = 20;

  const orders = await prisma.order.findMany({
    where: status ? { status: status as any } : undefined,
    include: { items: { include: { book: true } }, paymentMethod: true },
    orderBy: { createdAt: "desc" },
    skip: (page - 1) * pageSize,
    take: pageSize
  });

  return NextResponse.json({ orders, page, pageSize });
}
