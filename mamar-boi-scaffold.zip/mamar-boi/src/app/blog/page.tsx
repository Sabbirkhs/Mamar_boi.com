import Link from "next/link";
import { prisma } from "@/lib/prisma";

export default async function BlogListPage() {
  const posts = await prisma.post.findMany({
    where: { status: "PUBLISHED" },
    include: { author: { select: { name: true } }, _count: { select: { likes: true, comments: true } } },
    orderBy: { publishedAt: "desc" },
    take: 20
  });

  return (
    <main className="container" style={{ padding: "48px 20px" }}>
      <h1 className="display">ব্লগ</h1>
      <div style={{ display: "grid", gap: 20, marginTop: 24 }}>
        {posts.map((post) => (
          <Link
            key={post.id}
            href={`/blog/${post.slug}`}
            style={{ border: "1px solid var(--color-line)", borderRadius: 8, padding: 20, textDecoration: "none" }}
          >
            <h2 style={{ margin: 0, fontSize: "1.4rem" }}>{post.title}</h2>
            <p style={{ color: "var(--color-muted)", margin: "8px 0 0" }}>
              {post.author.name} · {post.readingTimeMin} মিনিট পড়া · {post._count.likes} লাইক · {post._count.comments} মন্তব্য
            </p>
          </Link>
        ))}
        {posts.length === 0 && <p style={{ color: "var(--color-muted)" }}>এখনও কোনো পোস্ট প্রকাশিত হয়নি।</p>}
      </div>
    </main>
  );
}
