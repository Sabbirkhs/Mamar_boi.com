import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";

export default async function BlogPostPage({ params }: { params: { slug: string } }) {
  const post = await prisma.post.findUnique({
    where: { slug: params.slug },
    include: { author: true, category: true, tags: { include: { tag: true } } }
  });

  if (!post || post.status !== "PUBLISHED") notFound();

  return (
    <main className="container" style={{ maxWidth: 720, padding: "48px 20px" }}>
      <h1 className="display" style={{ fontSize: "2.2rem" }}>{post.title}</h1>
      <p style={{ color: "var(--color-muted)" }}>
        {post.author.name} · {post.readingTimeMin} মিনিট পড়া
        {post.category ? ` · ${post.category.name}` : ""}
      </p>
      {/* content was sanitized server-side at creation time via sanitizeHtml() */}
      <article dangerouslySetInnerHTML={{ __html: post.content }} style={{ marginTop: 24, fontSize: "1.1rem" }} />
    </main>
  );
}
