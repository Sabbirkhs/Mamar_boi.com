import Link from "next/link";
import { prisma } from "@/lib/prisma";

export default async function BooksPage() {
  const books = await prisma.book.findMany({
    where: { hidden: false },
    orderBy: [{ featured: "desc" }, { createdAt: "desc" }]
  });

  return (
    <main className="container" style={{ padding: "48px 20px" }}>
      <h1 className="display">বই অর্ডার</h1>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))", gap: 20, marginTop: 24 }}>
        {books.map((book) => (
          <Link key={book.id} href={`/books/${book.slug}`} style={{ textDecoration: "none", color: "inherit" }}>
            <div style={{ border: "1px solid var(--color-line)", borderRadius: 8, overflow: "hidden" }}>
              <div style={{ aspectRatio: "3/4", background: "#EDE9E0" }} />
              <div style={{ padding: 12 }}>
                <strong>{book.title}</strong>
                <p style={{ margin: "4px 0", color: "var(--color-muted)" }}>{book.author}</p>
                <p style={{ margin: 0, fontWeight: 600 }}>
                  ৳{((book.discountPrice ?? book.price) / 100).toFixed(0)}
                  {book.discountPrice && (
                    <span style={{ textDecoration: "line-through", color: "var(--color-muted)", marginLeft: 8 }}>
                      ৳{(book.price / 100).toFixed(0)}
                    </span>
                  )}
                </p>
              </div>
            </div>
          </Link>
        ))}
        {books.length === 0 && <p style={{ color: "var(--color-muted)" }}>এখনও কোনো বই যোগ করা হয়নি।</p>}
      </div>
    </main>
  );
}
