import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import OrderForm from "./order-form";

export default async function BookDetailPage({ params }: { params: { slug: string } }) {
  const book = await prisma.book.findUnique({ where: { slug: params.slug } });
  if (!book || book.hidden) notFound();

  const paymentMethods = await prisma.paymentMethod.findMany({ where: { active: true }, orderBy: { sortOrder: "asc" } });

  return (
    <main className="container" style={{ padding: "48px 20px" }}>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1.4fr", gap: 40 }}>
        <div style={{ aspectRatio: "3/4", background: "#EDE9E0", borderRadius: 8 }} />
        <div>
          <h1 className="display">{book.title}</h1>
          <p style={{ color: "var(--color-muted)" }}>{book.author}</p>
          <p style={{ fontSize: "1.4rem", fontWeight: 700 }}>
            ৳{((book.discountPrice ?? book.price) / 100).toFixed(0)}
          </p>
          <p>{book.description}</p>
          <ul style={{ color: "var(--color-muted)" }}>
            {book.publisher && <li>প্রকাশক: {book.publisher}</li>}
            {book.edition && <li>সংস্করণ: {book.edition}</li>}
            {book.pages && <li>পৃষ্ঠা: {book.pages}</li>}
            <li>{book.stock > 0 ? `স্টকে আছে (${book.stock})` : "স্টক নেই"}</li>
          </ul>
          <OrderForm bookId={book.id} bookTitle={book.title} maxQty={book.stock} paymentMethods={paymentMethods} />
        </div>
      </div>
    </main>
  );
}
