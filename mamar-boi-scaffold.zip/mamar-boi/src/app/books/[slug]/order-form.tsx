"use client";

import { useState } from "react";

type PaymentMethod = { id: string; provider: string; instructions: string | null };

export default function OrderForm({
  bookId,
  bookTitle,
  maxQty,
  paymentMethods
}: {
  bookId: string;
  bookTitle: string;
  maxQty: number;
  paymentMethods: PaymentMethod[];
}) {
  const [qty, setQty] = useState(1);
  const [form, setForm] = useState({
    customerName: "",
    customerPhone: "",
    customerEmail: "",
    district: "",
    upazila: "",
    address: "",
    note: "",
    paymentMethodId: paymentMethods[0]?.id ?? "",
    paymentRef: ""
  });
  const [result, setResult] = useState<{ orderNumber: string } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    const res = await fetch("/api/orders", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...form, items: [{ bookId, quantity: qty }] })
    });
    const data = await res.json();
    setLoading(false);
    if (!res.ok) {
      setError(typeof data.error === "string" ? data.error : "অর্ডার সম্পন্ন করা যায়নি।");
      return;
    }
    setResult({ orderNumber: data.order.orderNumber });
  }

  if (result) {
    return (
      <div style={{ marginTop: 24, padding: 16, border: "1px solid var(--color-line)", borderRadius: 8 }}>
        <strong>আপনার অর্ডার সফল হয়েছে!</strong>
        <p>অর্ডার আইডি: {result.orderNumber}</p>
      </div>
    );
  }

  if (maxQty <= 0) return <p style={{ color: "crimson", marginTop: 16 }}>এই মুহূর্তে স্টক নেই।</p>;

  return (
    <form onSubmit={submit} style={{ display: "grid", gap: 10, marginTop: 24, maxWidth: 420 }}>
      <label>
        পরিমাণ
        <input
          type="number"
          min={1}
          max={maxQty}
          value={qty}
          onChange={(e) => setQty(Number(e.target.value))}
          style={{ display: "block", width: 80 }}
        />
      </label>
      <input placeholder="পূর্ণ নাম" required value={form.customerName} onChange={(e) => setForm({ ...form, customerName: e.target.value })} />
      <input placeholder="ফোন নম্বর" required value={form.customerPhone} onChange={(e) => setForm({ ...form, customerPhone: e.target.value })} />
      <input placeholder="ইমেইল (ঐচ্ছিক)" value={form.customerEmail} onChange={(e) => setForm({ ...form, customerEmail: e.target.value })} />
      <input placeholder="জেলা" required value={form.district} onChange={(e) => setForm({ ...form, district: e.target.value })} />
      <input placeholder="উপজেলা/থানা" required value={form.upazila} onChange={(e) => setForm({ ...form, upazila: e.target.value })} />
      <textarea placeholder="সম্পূর্ণ ঠিকানা" required value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
      <textarea placeholder="বিশেষ নোট (ঐচ্ছিক)" value={form.note} onChange={(e) => setForm({ ...form, note: e.target.value })} />

      <label>
        পেমেন্ট পদ্ধতি
        <select
          value={form.paymentMethodId}
          onChange={(e) => setForm({ ...form, paymentMethodId: e.target.value })}
          style={{ display: "block", width: "100%" }}
        >
          {paymentMethods.map((pm) => (
            <option key={pm.id} value={pm.id}>{pm.provider}</option>
          ))}
        </select>
      </label>
      {paymentMethods.find((pm) => pm.id === form.paymentMethodId)?.instructions && (
        <p style={{ color: "var(--color-muted)", fontSize: "0.9rem" }}>
          {paymentMethods.find((pm) => pm.id === form.paymentMethodId)?.instructions}
        </p>
      )}
      <input placeholder="লেনদেন আইডি (যদি প্রযোজ্য হয়)" value={form.paymentRef} onChange={(e) => setForm({ ...form, paymentRef: e.target.value })} />

      {error && <p style={{ color: "crimson" }}>{error}</p>}
      <button type="submit" disabled={loading}>
        {loading ? "..." : `"${bookTitle}" অর্ডার করুন`}
      </button>
    </form>
  );
}
