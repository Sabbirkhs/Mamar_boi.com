import type { NextAuthOptions } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import { PrismaAdapter } from "@next-auth/prisma-adapter";
import { prisma } from "./prisma";
import { verifyPassword } from "./password";
import { checkLoginRateLimit, recordFailedLogin, resetLoginAttempts } from "./rate-limit";

export const authOptions: NextAuthOptions = {
  adapter: PrismaAdapter(prisma),
  session: { strategy: "jwt", maxAge: 60 * 60 * 8 }, // 8h session, then re-auth
  pages: {
    signIn: "/login"
  },
  providers: [
    CredentialsProvider({
      name: "Email & Password",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" }
      },
      async authorize(credentials, req) {
        if (!credentials?.email || !credentials?.password) return null;

        const ip = (req?.headers?.["x-forwarded-for"] as string) ?? "unknown";
        const throttled = await checkLoginRateLimit(`${ip}:${credentials.email}`);
        if (throttled) {
          throw new Error("Too many attempts. Please try again in a few minutes.");
        }

        const user = await prisma.user.findUnique({ where: { email: credentials.email.toLowerCase() } });
        if (!user) {
          await recordFailedLogin(`${ip}:${credentials.email}`);
          return null;
        }

        if (user.status === "SUSPENDED") {
          throw new Error("This account has been suspended.");
        }

        const valid = await verifyPassword(credentials.password, user.passwordHash);
        if (!valid) {
          await recordFailedLogin(`${ip}:${credentials.email}`);
          return null;
        }

        await resetLoginAttempts(`${ip}:${credentials.email}`);

        return {
          id: user.id,
          name: user.name,
          email: user.email,
          username: user.username,
          role: user.role,
          image: user.avatarUrl ?? undefined
        };
      }
    })
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.id = user.id;
        token.role = (user as any).role;
        token.username = (user as any).username;
      }
      return token;
    },
    async session({ session, token }) {
      if (session.user) {
        (session.user as any).id = token.id;
        (session.user as any).role = token.role;
        (session.user as any).username = token.username;
      }
      return session;
    }
  },
  cookies: {
    sessionToken: {
      name: `${process.env.NODE_ENV === "production" ? "__Secure-" : ""}next-auth.session-token`,
      options: {
        httpOnly: true,
        sameSite: "lax",
        path: "/",
        secure: process.env.NODE_ENV === "production"
      }
    }
  }
};
