import { prisma } from "./prisma";

/**
 * Generates a human-friendly, unique order number like MB-2026-000123.
 * Uses a DB transaction with a count-based sequence per year; for very high
 * write concurrency, replace with a dedicated Sequence table + row lock.
 */
export async function generateOrderNumber(): Promise<string> {
  const year = new Date().getFullYear();
  const prefix = `MB-${year}-`;

  return prisma.$transaction(async (tx) => {
    const countThisYear = await tx.order.count({
      where: { orderNumber: { startsWith: prefix } }
    });
    const next = (countThisYear + 1).toString().padStart(6, "0");
    return `${prefix}${next}`;
  });
}
