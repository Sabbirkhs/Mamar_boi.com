import bcrypt from "bcryptjs";

const SALT_ROUNDS = 12;

export async function hashPassword(plain: string): Promise<string> {
  return bcrypt.hash(plain, SALT_ROUNDS);
}

export async function verifyPassword(plain: string, hash: string): Promise<boolean> {
  return bcrypt.compare(plain, hash);
}

// Basic server-side strength check. Never rely on client-side validation alone.
export function isPasswordStrongEnough(plain: string): boolean {
  return plain.length >= 8 && /[A-Za-z]/.test(plain) && /[0-9]/.test(plain);
}
