import { z } from "zod";
import DOMPurify from "isomorphic-dompurify";

export const registerSchema = z.object({
  name: z.string().min(2).max(80),
  username: z
    .string()
    .min(3)
    .max(30)
    .regex(/^[a-z0-9_.]+$/, "Lowercase letters, numbers, dots and underscores only"),
  email: z.string().email(),
  phone: z.string().min(6).max(20).optional(),
  password: z.string().min(8).max(128)
});

export const createPostSchema = z.object({
  title: z.string().min(3).max(200),
  excerpt: z.string().max(300).optional(),
  content: z.string().min(1),
  coverImageUrl: z.string().url().optional(),
  categoryId: z.string().optional(),
  tagIds: z.array(z.string()).max(10).optional()
});

export const createCommentSchema = z.object({
  content: z.string().min(1).max(2000),
  parentId: z.string().optional()
});

export const createBookSchema = z.object({
  title: z.string().min(1).max(200),
  author: z.string().min(1).max(120),
  description: z.string().min(1),
  coverImageUrl: z.string().url().optional(),
  price: z.number().int().positive(),
  discountPrice: z.number().int().positive().optional(),
  stock: z.number().int().min(0),
  pages: z.number().int().positive().optional(),
  publisher: z.string().optional(),
  edition: z.string().optional(),
  isbn: z.string().optional(),
  categoryIds: z.array(z.string()).optional()
});

export const createOrderSchema = z.object({
  items: z
    .array(z.object({ bookId: z.string(), quantity: z.number().int().positive().max(50) }))
    .min(1),
  customerName: z.string().min(2).max(120),
  customerPhone: z.string().min(6).max(20),
  customerEmail: z.string().email().optional(),
  district: z.string().min(1),
  upazila: z.string().min(1),
  postalCode: z.string().optional(),
  address: z.string().min(5),
  note: z.string().max(500).optional(),
  paymentMethodId: z.string(),
  paymentRef: z.string().max(100).optional()
});

/** Strips any script/event-handler content out of rich-text HTML before it is stored or rendered. */
export function sanitizeHtml(dirty: string): string {
  return DOMPurify.sanitize(dirty, {
    ALLOWED_TAGS: [
      "p", "br", "strong", "em", "u", "s", "h2", "h3", "h4", "blockquote",
      "ul", "ol", "li", "a", "img", "figure", "figcaption", "code", "pre"
    ],
    ALLOWED_ATTR: ["href", "src", "alt", "title", "target", "rel"]
  });
}
