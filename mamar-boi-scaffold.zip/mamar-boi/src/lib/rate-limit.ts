/**
 * Minimal login-attempt throttling.
 *
 * This in-memory version works for a single Node process and is fine to ship
 * with initially, but resets on every deploy/restart and won't be shared
 * across multiple server instances. For real production traffic, swap the
 * three functions below for calls to Upstash Redis (env vars are already
 * scaffolded in .env.example) or another shared store, keeping the same
 * function signatures so nothing else has to change.
 */

const MAX_ATTEMPTS = 5;
const WINDOW_MS = 10 * 60 * 1000; // 10 minutes

type Bucket = { count: number; firstAttemptAt: number };
const attempts = new Map<string, Bucket>();

export async function checkLoginRateLimit(key: string): Promise<boolean> {
  const bucket = attempts.get(key);
  if (!bucket) return false;
  if (Date.now() - bucket.firstAttemptAt > WINDOW_MS) {
    attempts.delete(key);
    return false;
  }
  return bucket.count >= MAX_ATTEMPTS;
}

export async function recordFailedLogin(key: string): Promise<void> {
  const bucket = attempts.get(key);
  if (!bucket || Date.now() - bucket.firstAttemptAt > WINDOW_MS) {
    attempts.set(key, { count: 1, firstAttemptAt: Date.now() });
  } else {
    bucket.count += 1;
  }
}

export async function resetLoginAttempts(key: string): Promise<void> {
  attempts.delete(key);
}
