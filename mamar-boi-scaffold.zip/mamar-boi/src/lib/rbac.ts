import { Role } from "@prisma/client";
import { getServerSession } from "next-auth";
import { authOptions } from "./auth";

// Ordered from least to most privileged for simple comparisons.
const ROLE_RANK: Record<Role, number> = {
  USER: 0,
  WRITER: 1,
  EDITOR: 2,
  ADMIN: 3,
  SUPER_ADMIN: 4
};

export function hasAtLeastRole(userRole: Role, minimumRole: Role): boolean {
  return ROLE_RANK[userRole] >= ROLE_RANK[minimumRole];
}

/**
 * Returns the current session, or null. Every API route/server action that
 * touches user- or admin-scoped data must call this (or requireRole) —
 * never trust a client-supplied user id or role.
 */
export async function getCurrentUser() {
  const session = await getServerSession(authOptions);
  return session?.user ?? null;
}

export class UnauthorizedError extends Error {
  status = 401;
}
export class ForbiddenError extends Error {
  status = 403;
}

/** Throws if there is no logged-in user. Returns the session user otherwise. */
export async function requireUser() {
  const user = await getCurrentUser();
  if (!user) throw new UnauthorizedError("Sign in required");
  return user;
}

/** Throws unless the logged-in user's role is at least `minimumRole`. */
export async function requireRole(minimumRole: Role) {
  const user = await requireUser();
  if (!hasAtLeastRole(user.role as Role, minimumRole)) {
    throw new ForbiddenError("Insufficient permissions");
  }
  return user;
}

/** Throws unless the user owns the resource OR is at least `overrideRole` (e.g. an editor deleting any comment). */
export async function requireOwnerOrRole(resourceOwnerId: string, overrideRole: Role) {
  const user = await requireUser();
  if (user.id === resourceOwnerId) return user;
  if (hasAtLeastRole(user.role as Role, overrideRole)) return user;
  throw new ForbiddenError("You can only modify your own content");
}
