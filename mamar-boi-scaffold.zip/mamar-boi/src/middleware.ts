import { withAuth } from "next-auth/middleware";
import { NextResponse } from "next/server";

const ADMIN_ROLES = new Set(["ADMIN", "SUPER_ADMIN"]);

export default withAuth(
  function middleware(req) {
    const token = req.nextauth.token;
    const isAdminRoute = req.nextUrl.pathname.startsWith("/admin");

    if (isAdminRoute && !ADMIN_ROLES.has((token?.role as string) ?? "")) {
      return NextResponse.redirect(new URL("/", req.url));
    }
    return NextResponse.next();
  },
  {
    callbacks: {
      // Any matched route requires at least a valid session; the function
      // above adds the extra role check for /admin specifically.
      authorized: ({ token }) => !!token
    },
    pages: { signIn: "/login" }
  }
);

export const config = {
  matcher: ["/dashboard/:path*", "/admin/:path*"]
};
